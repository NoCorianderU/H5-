// const db = require('../tools/mongodb').getDB()

// module.exports = async ctx => {
//   // ctx.state.data = {
//   //   msg: {
//   //     "nickName":".",
//   //     "avatarUrl":"http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKianQdXN3w1OHjRiaVfLibdpJv4GCWEicYMp7EcDMY80wu47pH3nicb9zicjJQU3weORIRO4Fibo8HBMgpg/132",
//   //     "gender":1,
//   //     "province":"Shandong",
//   //     "city":"Taian"
//   //   }
//   // }
//   console.time('bbb')
//   let data = await db.find('stu')
//   console.timeEnd('bbb')
//   ctx.body = data
// }
