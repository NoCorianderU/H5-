
// const db = require('../tools/mongodb').getDB()
require('../tools/mongoose')
const user = require('../models/user')

module.exports = async ctx => {
  let data = await user.countDocuments()
    ctx.state.data = {
      msg: data
    }
}
