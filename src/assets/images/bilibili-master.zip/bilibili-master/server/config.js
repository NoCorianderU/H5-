const CONF = {
    port: '3000',
}

module.exports = CONF
