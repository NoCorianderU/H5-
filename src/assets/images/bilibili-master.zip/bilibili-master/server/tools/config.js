
const config  = {
  url: 'mongodb://localhost:27017',
  dbName: 'test'
}

module.exports =  config
