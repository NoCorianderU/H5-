<template>
  <div class="navList clearfix">
    <ul class="clearfix fl mainList">
      <li>
        <router-link to="/" tag="a" class="mainBtn"><span></span><p>首页</p></router-link>
      </li>
      <li>
        <router-link to="/animate" tag="a" class="mainBtn"><span><i>998</i></span><p>动画</p></router-link>
        <ul class="subList">
          <li><a href=""><span>MAD·AMV</span></a></li>
          <li><a href=""><span>MMD·3D</span></a></li>
          <li><a href=""><span>短片·手书·配音</span></a></li>
          <li><a href=""><span>综合</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>126</i></span><p>番剧</p></a>
        <ul class="subList">
          <li><a href=""><span>连载动画</span></a></li>
          <li><a href=""><span>完结动画</span></a></li>
          <li><a href=""><span>资讯</span></a></li>
          <li><a href=""><span>官方延伸</span></a></li>
          <li><a href=""><span>新番时间表</span></a></li>
          <li><a href=""><span>番剧索引</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>96</i></span><p>国创</p></a>
        <ul class="subList">
          <li><a href=""><span>国创动画</span></a></li>
          <li><a href=""><span>国产原创相关</span></a></li>
          <li><a href=""><span>布袋戏</span></a></li>
          <li><a href=""><span>资讯</span></a></li>
          <li><a href=""><span>新番时间表</span></a></li>
          <li><a href=""><span>国产动画索引</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>音乐</p></a>
        <ul class="subList">
          <li><a href=""><span>原创音乐</span></a></li>
          <li><a href=""><span>翻唱</span></a></li>
          <li><a href=""><span>VOCALOID·UTAU</span></a></li>
          <li><a href=""><span>演奏</span></a></li>
          <li><a href=""><span>三次元音乐</span></a></li>
          <li><a href=""><span>OP/ED/OST</span></a></li>
          <li><a href=""><span>音乐选集</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>215</i></span><p>舞蹈</p></a>
        <ul class="subList">
          <li><a href=""><span>宅舞</span></a></li>
          <li><a href=""><span>三次元舞蹈</span></a></li>
          <li><a href=""><span>舞蹈教程</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>游戏</p></a>
        <ul class="subList">
          <li><a href=""><span>单机游戏</span></a></li>
          <li><a href=""><span>电子竞技</span></a></li>
          <li><a href=""><span>手机游戏</span></a></li>
          <li><a href=""><span>网络游戏</span></a></li>
          <li><a href=""><span>桌游棋牌</span></a></li>
          <li><a href=""><span>GMV</span></a></li>
          <li><a href=""><span>音游</span></a></li>
          <li><a href=""><span>MUGEN</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>科技</p></a>
        <ul class="subList">
          <li><a href=""><span>趣味科普人文</span></a></li>
          <li><a href=""><span>野生技术协会</span></a></li>
          <li><a href=""><span>演讲·公开课</span></a></li>
          <li><a href=""><span>星海</span></a></li>
          <li><a href=""><span>数码</span></a></li>
          <li><a href=""><span>机械</span></a></li>
          <li><a href=""><span>汽车</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>生活</p></a>
        <ul class="subList">
          <li><a href=""><span>搞笑</span></a></li>
          <li><a href=""><span>日常</span></a></li>
          <li><a href=""><span>美食圈</span></a></li>
          <li><a href=""><span>动物圈</span></a></li>
          <li><a href=""><span>手工</span></a></li>
          <li><a href=""><span>绘画</span></a></li>
          <li><a href=""><span>运动</span></a></li>
          <li><a href=""><span>其他</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>83</i></span><p>鬼畜</p></a>
        <ul class="subList">
          <li><a href=""><span>鬼畜调教</span></a></li>
          <li><a href=""><span>音MOD</span></a></li>
          <li><a href=""><span>人力VOCALOID</span></a></li>
          <li><a href=""><span>教程演示</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>512</i></span><p>时尚</p></a>
        <ul class="subList">
          <li><a href=""><span>美妆</span></a></li>
          <li><a href=""><span>服饰</span></a></li>
          <li><a href=""><span>健身</span></a></li>
          <li><a href=""><span>资讯</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>107</i></span><p>广告</p></a>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>娱乐</p></a>
        <ul class="subList">
          <li><a href=""><span>综艺</span></a></li>
          <li><a href=""><span>明星</span></a></li>
          <li><a href=""><span>Korea相关</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>999+</i></span><p>影视</p></a>
        <ul class="subList">
          <li><a href=""><span>影视杂谈</span></a></li>
          <li><a href=""><span>影视剪辑</span></a></li>
          <li><a href=""><span>短片</span></a></li>
          <li><a href=""><span>预告·资讯</span></a></li>
          <li><a href=""><span>特摄</span></a></li>
        </ul>
      </li>
      <li>
        <a href="" class="mainBtn"><span><i>181</i></span><p>放映厅</p></a>
        <ul class="subList">
          <li><a href=""><span>纪录片</span></a></li>
          <li><a href=""><span>电影</span></a></li>
          <li><a href=""><span>电视剧</span></a></li>
        </ul>
      </li>
      <li class="right_nav">
        <a href=""><span class="zl"></span><p>专栏</p></a>
      </li>
      <li class="right_nav">
        <a href=""><span class="gc"></span><p>广场</p></a>
      </li>
      <li class="right_nav">
        <a href=""><span class="zb"></span><p>直播</p></a>
      </li>
      <li class="right_nav">
        <a href=""><span class="xhw"></span><p>小黑屋</p></a>
      </li>
    </ul>
    <div class="gif fr">
      <img src="../images/goal.gif" alt="">
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="scss" scoped>
.navList{
  margin: 14px 0 5px;
  .mainList{
    li{
      position: relative;
      width: 48px;
      height: 44px;
      float: left;
      margin-right: 11px;
      &:hover .subList{
        display: block;
      }
      &:first-child{
        margin-right: -6px;
        .mainBtn{
          text-align: left;
          span{
            width: 18px;
            height: 16px;
            display: inline-block;
            margin: 0 3px;
            background: url('../images/icons.png') no-repeat -663px -1176px;
            padding: 0;
          }
        }
      }
      .mainBtn{
        display: block;
        height: 100%;
        text-align: center;
        span{
          min-width: 18px;
          height: 12px;
          display: inline-block;
          background: #FFAFC9;
          border-radius: 3px;
          margin: 3px 0 4px;
          i{
            display: inline-block;
            padding: 1px 1px 0;
            max-width: 28px;
            line-height: 12px;
            transform: scale(0.8, 0.88);
            color: #FFF;
            font-style: normal;
            font-family: sans-serif;
          }
        }
        p{
          line-height: 16px;
          font-size: 11px;
          color: #222;
        }
      }
      .subList{
        display: none;
        position: absolute;
        top: 38px;
        left: 0;
        width: 130px;
        z-index: 100;
        box-shadow: 0 2px 4px rgba(0,0,0,.16);
        border-radius: 0 0 4px 4px;
        li{
          float: none;
          width: 130px;
          height: 30px;
          line-height: 30px;
          background: #fff;
          overflow: hidden;
          &:hover{
            background: #e5e9ef;
            a{
              margin-left: 5px;
              span::after{
                opacity: 1;
                right: -20px;
              }
            }
          }
          a{
            display: block;
            padding-left: 25px;
            text-align: left;
            background: url('//s1.hdslb.com/bfs/static/jinkela/home/images/icons2.png') no-repeat 12px -1613px;
            transition: .2s;
            span{
              position: relative;
            }
            span::after{
              position: absolute;
              right: -120px;
              top: -3px;
              content: "";
              background: url('//s1.hdslb.com/bfs/static/jinkela/home/images/icons2.png') no-repeat 0 -1581px;
              width: 15px;
              height: 18px;
              display: block;
              opacity: 0;
              transition: .2s;
            }
          }
        }
      }
    }
    .right_nav{
      width: 52px;
      height: 100%;
      text-align: center;
      margin: 0;
      a{
        display: block;
        &:hover{
          color: #00A1D6;
        }
        span{
          display: block;
          width: 18px;
          height: 16px;
          background: url('../images/icons.png') no-repeat -87px -1816px;
          margin: -1px 0 2px 17px;
        }
      }
      .gc{
          background-position: -87px -2008px;
        }
      .zb{
        background-position: -87px -1880px;
      }
      .xhw{
        background-position: -87px -1944px;
      }
    }
  }
  .gif{
    margin-top: -7px;
    img{
      border-radius: 3px;
    }
  }
}
</style>

