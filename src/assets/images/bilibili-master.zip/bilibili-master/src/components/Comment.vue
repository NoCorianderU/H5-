<template>
  <div class="commentLayout">
    <ul class="comments">
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#241</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
            <ul class="userInteraction">
            </ul>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#241</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#240</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#239</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#238</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
            <ul class="userInteraction">
              <li>
                <div class="replyInfo clearfix">
                  <div class="replyHead fl">
                    <a href="javascript:;"><img src="../images/test2.webp" alt=""></a>
                  </div>
                  <div class="replyComment fr">
                    <p class="replyText"><a href="javascript;;" class="userId">TiCache<span></span></a>开包开出个🐸</p>
                    <div class="replyActions">
                      <span class="comTime">2018-08-10 07:40</span>
                      <span class="skr"><i class="iconfont icon-dianzan"></i>4</span>
                      <span class="interaction">回复</span>
                    </div>
                  </div>
                </div>
              </li>
              <!-- <li class="replyLength">共<span>20</span>条回复,<a href="javascript:;">点击查看</a></li> -->
            </ul>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#237</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
          </div>
        </div>
      </li>
      <li>
        <div class="commentContent clearfix">
          <div class="userInfo fl">
            <a href="javascript:;"><img src="../images/test.webp" alt=""></a>
          </div>
          <div class="commentDetails fl">
            <a href="javascript;;" class="userId">在下叶良翔<span></span></a>
            <p class="commentText">炉石开包出个米宝？</p>
            <div class="commentActions">
              <span class="index">#238</span>
              <span class="mobile">来自<a href="javascript:;">安卓客户端</a></span>
              <span class="comTime">2018-08-10 07:40</span>
              <span class="skr"><i class="iconfont icon-dianzan"></i>183</span>
              <span class="noskr"><i class="iconfont icon-tread"></i></span>
              <span class="interaction">回复</span>
            </div>
            <ul class="userInteraction">
              <!-- <li class="replyLength">共<span>20</span>条回复,<a href="javascript:;">点击查看</a></li> -->
            </ul>
          </div>
        </div>
      </li>
    </ul>
     <div class="commentsListIndex clearfix">
       <ul class="clearfix fl">
        <li class="page"><a href="javascript:;">上一页</a></li>
        <li><a href="javascript:;">1</a></li>
        <li class="active"><a href="javascript:;">2</a></li>
        <li><a href="javascript:;">3</a></li>
        <li><a href="javascript:;">4</a></li>
        <li>...</li>
        <li><a href="javascript:;">12</a></li>
        <li class="page"><a href="javascript:;">下一页</a></li>
      </ul>
      <div class="changeIndex fr">
        共12页，跳至<input type="text">页
      </div>
     </div>
    <CommentInput/>
  </div>
</template>

<script>
import CommentInput from '@/components/CommentInput'

export default {
  components: {
    CommentInput
  },
}
</script>

<style lang="scss" scoped>
 .commentLayout {
  padding-bottom: 90px;
  .comments {
    li {
      margin-bottom: 17px;
      .commentContent {
        display: flex;
        .userInfo {
          margin-top: 7px;
          padding-left: 5px;
          display: flex;
          flex-direction: column;
          img {
            width: 48px;
            height: 48px;
            border-radius: 50%;
          }
          .followBtn {
            margin-top: 15px;
            display: inline-block;
            width: 48px;
            height: 24px;
            color: #fff;
            line-height: 26px;
            text-align: center;
            background: #00A1D6;
            border-radius: 4px;
          }
        }
        .commentDetails {
          flex: 1;
          margin-left: 32px;
          padding-top: 8px;
          padding-bottom: 19px;
          border-bottom: 1px solid #E5E9EF;
          .userId {
            font-size: 12px;
            color: #6D757A;
            font-weight: bold;
          }
          .bigbig {
            color: #FB7299;
          }
          .commentText {
            margin-top: 7px;
            font-size: 14px;
            line-height: 20px;
            width: 785px;
          }
          .commentActions {
            position: relative;
            font-family: Microsoft YaHei,Arial,Helvetica,sans-serif;
            margin-top: 6px;
            color: #99A2AA;
            span {
              display: inline-block;
              i {
                font-size: 16px;
                margin-right: 3px;
              }
            }
            .mobile {
              margin-left: 16px;
              a {
                color: #99A2AA;
                transition: .3s;
                &:hover {
                  color: #00A1D6;
                }
              }
            }
            .comTime {
              margin-left: 16px;
            }
            .skr, .noskr {
              margin-left: 16px;
              cursor: pointer;
              &:hover {
                color: #00A1D6;
              }
            }
            .interaction {
              position: absolute;
              left: 350px;
              top: 1px;
              margin-left: 16px;
              cursor: pointer;
              &:hover {
                width: 34px;
                height: 26px;
                left: 345px;
                top: -4px;
                line-height: 26px;
                text-align: center;
                color: #00A1D6;
                background: #E5E9EF;
                border-radius: 3px;
              }
            }
          }
          .userInteraction {
            font-family: Microsoft YaHei,Arial,Helvetica,sans-serif;
            li {
              margin-bottom: 10px;
              .replyHead {
                padding-top: 20px;
                img {
                  width: 24px;
                  height: 24px;
                  border-radius: 50%;
                }
              }
              .replyComment {
                padding-top: 15px;
                width: 750px;
                .replyText {
                  font-size: 14px;
                  a {
                    display: inline-block;
                    padding-right: 42px;
                    vertical-align: middle;
                  }
                }
                .replyActions {
                  margin-top: 10px;
                  color: #99A2AA;
                  .skr {
                    margin-left: 16px;
                    i {
                      margin-right: 3px;
                    }
                  }
                  .interaction {
                    margin-left: 21px;
                  }
                }
              }
            }
            .replyLength {
              margin-top: 13px;
              color: #6D757A;
              span {
                font-weight: bold;
              }
              a {
                display: inline-block;
                margin-left: 7px;
                color:  #00A1D6;
              }
            }
          }
        }
        .userInteraction {
          font-family: Microsoft YaHei,Arial,Helvetica,sans-serif;
          li {
            margin-bottom: 10px;
            .replyHead {
              padding-top: 20px;
              img {
                width: 24px;
                height: 24px;
                border-radius: 50%;
              }
            }
            .replyComment {
              margin-left: 10px;
              padding-top: 15px;
              .replyText {
                font-size: 14px;
                a {
                  display: inline-block;
                  padding-right: 42px;
                  vertical-align: middle;
                }
              }
              .replyActions {
                margin-top: 10px;
                color: #99A2AA;
                .skr {
                  margin-left: 16px;
                  i {
                    margin-right: 3px;
                  }
                }
                .interaction {
                  margin-left: 21px;
                }
              }
            }
          }
          .replyLength {
            margin-top: 13px;
            color: #6D757A;
            span {
              font-weight: bold;
            }
            a {
              display: inline-block;
              margin-left: 7px;
              color:  #00A1D6;
            }
          }
        }
      }
    }
  }
  .commentsListIndex {
    margin-top: 20px;
    ul {
      margin-left: 2px;
      margin-bottom: 20px;
      font-family: Microsoft YaHei,Arial,Helvetica,sans-serif;
      li {
        float: left;
        margin-right: 4px;
        width: 37px;
        vertical-align: middle;
        line-height: 36px;
        text-align: center;
        a {
          display: inline-block;
          padding: 0 10px;
          min-width: 15px;
          font-size: 14px;
          border: 1px solid #DDD;
          border-radius: 4px;
          transition: .3s;
          &:hover {
            color: #fff;
            background: #00A1D6;
            border-color: #00A1D6;
          }
        }
      }
      .page {
        width: 74px;
        a {
          padding: 0 15px;
        }
      }
      .active {
        a {
          color: #fff;
          background: #00A1D6;
          border-color: #00A1D6;
        }
      }
    }
    .changeIndex {
      margin-top: 7px;
      height: 26px;
      line-height: 26px;
      color: #99A2AA;
      input {
        box-sizing: border-box;
        margin: 0 5px;
        padding: 0 10px;
        width: 46px;
        height: 26px;
        font-size: 12px;
        text-align: center;
        line-height: 24px;
        border: 1px solid #ccc;
        border-radius: 4px;
      }
      .focus {
        border-color: #00A1D6;
      }
    }
  }
 }
</style>

