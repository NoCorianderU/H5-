import Vue from 'vue'
import Router from 'vue-router'

import Index from '@/views/index.vue'
const register = () => import('@/views/register')
const account = () => import('@/views/account')
const video = () => import('@/views/video')

const phone = () => import('@/components/register/RePhone')
const email = () => import('@/components/register/ReEmail')
const login = () => import('@/components/Login')
const action = () => import('@/components/Action')
const home = () => import('@/components/account/AccountHome')

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: Index
    },

    {
      path: '/register',
      name: 'register',
      component: register,
      children: [
        {
          path: 'phone',
          component: phone,
          meta:{
            title:'哔哩哔哩弹幕视频网 - ( ゜- ゜)つロ 乾杯~ - bilibili'
          }
        },
        {
          path: 'email',
          component: email,
          meta:{
            title:'哔哩哔哩弹幕视频网 - ( ゜- ゜)つロ 乾杯~ - bilibili'
          }
        },
      ]
    },

    {
      path: '/login',
      name: 'login',
      component: login
    },

    {
      path: '/action',
      name: 'action',
      component: action
    },

    {
      path: '/account',
      name: 'account',
      component: account,
      meta:{
        title: '哔哩哔哩弹幕视频网 - ( ゜- ゜)つロ 乾杯~ - bilibili'
      },
      children: [
        {
          path: 'home',
          component: home
        },
        {
          path: 'email',
          component: email
        },
      ]
    },

    {
      path: '/video/:av',
      name: 'video',
      props: true,
      component: video
    }
      // path: '/animate/:id',
      // props: true,
      // props: (route) => ({id: route.query.a}),
      // children: [
      //   {
      //     path: 'test',
      //     component: Index
      //   }
      // ],
      // beforeEnter(to, from, next) {   }
  ],
  mode: 'history'
  // fallback: false
})
