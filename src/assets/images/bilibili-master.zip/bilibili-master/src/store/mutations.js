export default {
  setUserInfo (state, { data }) {
    state.user = data
  }
}
