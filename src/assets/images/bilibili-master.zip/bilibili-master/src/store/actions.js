import axios from 'axios'

export default {
  async requestUserInfo (store, { user }) {
    let { data } = await axios({
      url: 'http://account.nocori.top/request',
      params: {
        username: user
      }
    })
    store.commit('setUserInfo', { data: data.data })
  }
}
