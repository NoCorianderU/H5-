export default {
  user: ''
}
